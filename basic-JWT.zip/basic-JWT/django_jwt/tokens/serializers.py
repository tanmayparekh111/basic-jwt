from rest_framework import serializers
from .models import UserData

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserData
        fields =['id','email','name','password']

    def create(self,validate_data):
        user = UserData.objects.create(email =validate_data['email'],
                                       name = validate_data['name'])
        
        user.set_password(validate_data['password'])
        user.save()

        return user
    

